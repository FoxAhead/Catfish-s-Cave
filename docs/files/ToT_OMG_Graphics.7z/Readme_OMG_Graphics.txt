Graphics Modpack for Techumseh's Operation Market-Garden Scenario
=================================================================

I played this scenario back in 2004 and, as I almost always do, ended up changing the graphics at the same time, particularly the terrain and cities. The modification retains most of the original units, but some have been replaced with more recent icons. This pack is unofficial; it was only ever intended for personal use, but over the years there have been some requests for it - so here it is.

This mod requires Techumseh's original scenario (http://www.tecumseh.150m.com/OM-G/OMGmain.html) and the Test of Time Patch Project (http://forums.civfanatics.com/showthread.php?t=517282).

Installation
============

1. Extract the contents of the archive into the Market-Garden scenario folder and overwrite the original files.
2. The ToTPP's 'No stack kills' option and 'Incremental rush buying' exploit fix are enabled in the game's rules file. If you wish to play using these options, tick the corresponding boxes in the ToTPP launcher.
3. To hide the health bars for Ferry and Horsa Glider units, tick the 'Override health bars' option in the ToTPP launcher.
4. Under Graphic Options (Ctrl+P), disable Animated Units.

Files
=====

Cities.bmp
Icons.bmp
Improvements.bmp
Terrain1.bmp
Terrain2.bmp
Units.bmp
Resource.spr
Rules.txt


Art Credits
===========

Cities, Terrain and Units Art
�����������������������������
Where known, signatures are provided in the graphics files:

GB = Gareth "Fairline" Birch
The catfish symbol = I wonder?
Tec = Techumseh
CS = Curt Sibling
CH = Sarsstock

AoK = Age of Kings (Ensemble Studios)
MP = MicroProse/Hasbro
TT = Transport Tycoon (MicroProse)
Legion = Legion (Slitherine Software)
Civ3 = Civilization 3 (Firaxis)
BG2 = Baldur's Gate 2 (Bioware)

Icons
�����
Mostly MicroProse, Techumseh and Curt Sibling, with Mercator's smooth tile grids.


Updates
=======

28/02/2020

* Added @COSMIC2 movement multiplier entries to the rules file to fix a long-standing ToTPP bug that allowed unlimited movement on roads and rivers, and the same for alpine units.
* Added more recent versions of Fairline's unit graphics.

16/09/2014

* ToTPP v0.9 version. Includes 8-frame combat animation from Icons.bmp.


Catfish
http://users.tpg.com.au/jpwbeest/

4/11/2008