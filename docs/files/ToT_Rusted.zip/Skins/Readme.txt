Rusted Skin Set for Test of Time
================================

Installation
������������
1. Extract the zip file into your main Test of Time directory. This will create a new folder called Skins.
2. Open this folder and double-click the file Install Rusted.bat.
3. To install the skin, type 1. The batch file will automatically backup your original files. To uninstall the skin and restore the original files, type 2. To cancel, type 3.


Files
�����
Civwin_back.bmp
Dialog.bmp
City.bmp
Icons.bmp
Install Rusted.bat


Art Credits
�����������
Microprose/Hasbro
Catfish
id Software
Advances icons in Icons.bmp by Bernd "BeBro" Brosing
Smooth tile grids by Mercator


Catfish

26/04/2005

(last updated 11/03/2006)