Graphics Modpack for Techumseh's Operation Market-Garden Scenario
=================================================================

I played this scenario back in 2004 and, as I almost always do, ended up changing the graphics at the same time, particularly the terrain and cities. The modification retains most of the original units, but some have been replaced with more recent icons. This pack is unofficial; it was only ever intended for personal use, but over the years there have been some requests for it - so here it is.

Files
�����
Cities.bmp
Icons.bmp
Improvements.bmp
Terrain1.bmp
Terrain2.bmp
Units.bmp
Resource.spr*
Rules.txt*

* Used to remove interference from Original game sprites.


Art Credits
�����������
Cities, Terrain and Units Art

Where known, signatures are provided in the graphics files:

GB = Gareth "Fairline" Birch
The catfish symbol = I wonder?
Tec = Techumseh
CS = Curt Sibling
CH = Sarsstock

AoK = Age of Kings (Ensemble Studios)
MP = MicroProse/Hasbro
TT = Transport Tycoon (MicroProse)
Legion = Legion (Slitherine Software)
Civ3 = Civilization 3 (Firaxis)
BG2 = Baldur's Gate 2 (Bioware)

Icons

Mostly MicroProse, Techumseh and Curt Sibling, with Mercator's smooth tile grids.


Catfish

4/11/2008