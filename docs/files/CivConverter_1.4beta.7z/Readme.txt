CivConverter V1.4
Beta Version
by Angelo Scotto (e_mail:scotto_a@hotmail.com)

README FILE

like the name itself say, CivConverter is a program capable to transform Civ2 Scenarios into Civ2TOT compatibile version.
It is able to convert exactly all scenarios for Civ2 (except for those scenarios which use Major Objective Flags), this means all Civ2 & CiC scenarios, a lot of FW scenarios and near all MGE scenarios.
CivConverter is also capable to convert graphic files only, if you just want to convert some wonderful Civ2 icons into your TOT Scenario.
Now i've added some simple error checking,eliminated virtually all differences between Civ2 classic scenarios and Tot converted versions; Ok, I still have problems with the Renaissance cities (read below).
still no GUI (have some patience...).
A lot of problems of version 1.3 are fixed with this version (see (6) and (8)) and i've to say that this version seems to be a stable one and i keep the beta name only because still exists the first turn bug.
Fell free to write me for any suggestion, question or other things like these.

(0)REQUIREMENTS
-TOT V1.1 (in other words ToT with the patch installed)
-No others...

(1)INSTALL CIVCONVERTER
Well, if you downloaded the complete version (360 kb) you only have to unzip it in a directory you like and you've installed CivConverter; quite simple.

(2)GRAPHIC FILES (IMPORTANT)
When i started to work on this project i was sure (don't ask me why...) that Civ2TOT BMP files were created using truecolor (24 bits), when i tested my graphics routines i noticed (very disappointing, trust me) that Civ2TOT BMP files were created using HiColors (16 bit) and so graphics came out fuzzy.
So i've decided to convert TOT bmp(16 bit) files into TrueColor files (24 bit),and this is a very IMPORTANT thing to note.

--------GIF SECTION
Civ2 old graphics files are saved in GIF format, since i don't want to pay rights to unisys i won't create any GIF decoder into my program (if you know a freeware library to decode GIFs which doesn't use Limpel-Ziv Algorithm write me an e-mail)
So, when you decide to convert a scenario you have to open your favorite paint program (i've tested this procedure with Paint program you get with windows), load GIF files and save them as BMP files (24 bits remember...) in the same directory
REMEMBER: if you still wants to use scenarios with FW or MGE after the conversion, you must re-convert 24-bit bmp into gif.
(if you feel i've been not clear look at the example in the (4)CONVERTING A SCENARIO section)


(3)SYNOPSIS:
*Converting Scenarios
CivConverter <FileScenario>
where <FileScenario> is the name (with the complete path!) of the scenario file to convert
*Converting Graphic files
CivConverter <par1> <Directory>
where <par1> 	  can be "/g1" to convert graphic from Civ2 Classic or CIC
	     	  or "/g2" to convert graphic from Fantastic Worlds or MGE
      <Directory> is the directory (remember: complete path!) containing 
		  graphic files to convert

(4)CONVERTING A SCENARIO
This operation consist of two phases
--------PREPARE TO CONVERT A SCENARIO
You have to locate your Scenario Directory (for example "c:\Microprose\Civ2\scenario\Alien") and CivConverter directory (for example: "c:\Microprose\Civ2TOT\CivConverter")
Open Scenario directory and CONVERT (look at the previous section) all graphics files from GIF to True Color BMP using your favorite paint program.
--------GO ON,CONVERT IT!
Open a DOS Prompt and move to CivConverter directory (for example: "cd c:\Microprose\Civ2TOT\CivConverter")
Launch CivConverter with scenario filename (and PATH!) as parameter (for example: "CivConverter c:\Microprose\Civ2\Scenario\Alien\Alien.scn")
Wait...time passes
Wait...time passes
When the screen shows "Conversion Terminated" you've finished.
CivConverter creates a directory in the scenario directory called Converted so, the Civ2TOT converted version lies into the "Converted" subdirectory of original scenario directory (for example: c:\Microprose\Civ2\Scenario\Alien\Converted contains the TOT version of Alien.scn)
--------COMPLETE EXAMPLE
In this example i'll explain how to convert Colonization Scenario (from Gary Longo), you can find it at http://sleague.apolyton.net/Reviews/ch_colo.shtml
I choose this Scenario because is a CIC scenario, redefines all graphic files and uses some events and so quite all routines of CivConverter must do some work...
0)Install CivConverter into (let's say) "c:\mps\civ2TOT\CivConverter"
1)After downloading Scenario unzip it into "c:\windows\desktop\colonize"
2)Convert all gif files to bmp files (24-bits) using a paint program (Windows Paint program is perfect) (in this case you'll have to convert Units, Cities, Icons, people, terrain1, terrain2)
3)Open a dosprompt
4)Change directory to c:\mps\civ2TOT\CivConverter (cd c:\mps\civ2TOT\CivConverter)
5)launch CivConverter on colonization scn file:
	("CivConverter c:\windows\desktop\colonize\colonize.scn")
6)wait and (if you're lucky ;-)) you'll see the "Conversion Terminated" message
7)launch Civ2TOT and load colonize.scn scenario found into c:\windows\desktop\colonize\converted\
8)Play a Civ2 Scenario using TOT...

NOTE ON FANTASTIC WORLDS SCENARIOS (FIRST TURN BUG)
In this version i've fixed a lot of bugs into FW conversion routines (thanks to the help of Cary Semar), and so today you can use CivConverter with FW scenarios (i've successfully converted the winner of the second scenario contest barron1 without problems apart from renaissance bug) BUT i've not been able to fix the first turn bug so some FW scenarios (those with Major Objective Flags enabled) cannot be converted successfully; luckily it seems that these scenarios are very few (sadly near all WW2 scenarios use Major Objectives Flags).


(5)GRAPHIC CONVERTER
Converting graphic is very simple:
all you've to do is to CONVERT(read paragraph (2)) graphic files you want to convert into BMP 24-bit versions and save it.
Open a DOS prompt and move to CivConverter Directory
Then you've to launch CivConverter with /g1 or /g2 parameter (use /g1 to convert from Classic/CIC and /g2 to convert from FW/MGE) and the directory in which graphic BMP files lie:
Example: Say you want to convert Alien (a CIC Scenario) graphic files (with Alien Scenario in c:\microprose\Civ2\Scenario\Alien) and you've already converted images from gif to bmp(24-bit remember)
you've to write at the DOSPrompt:

"CivConverter /g1 c:\Microprose\Civ2\Scenario\Alien"

quite easy.

(6)DIFFERENCES BETWEEN ORIGINAL SCENARIOS AND TOT CONVERSIONS(AKA: BUGS KNOWN)
Alas, this is a beta, and it is free, and i've no scenario formats , what do you expect? perfection? no way.
I've found some bugs in scenarios converted versions (and i need you to test CivConverter and warn me about other bugs not listed here), none of this bugs seems to alter play but they can be tiresome.
*RENAISSANCE CITY IMAGE
Since in Civ2 there wasn't a special icon for the renaissance age while in TOT this icon was placed in the Alternative Modern row (see cities.gif), now in some scenarios (i've found the problem testing the Hodadians scenario in CIC and in barron scenario of Mark Laanen) some nations get Alternative Modern cities because of this problem, i don't have any clue to solve this but i've a lot of more important things to do (read above-mentioned problems) (hmmm... now i don't have excuses, ok i'll start to think about it)
None other bug until now...

(7)THINGS TO DO (a lot...)
-Modify graphics alghoritm to use 16 bit bmp files instead of 24 bit version (freeing up to 1/3 of space took by images in this version)
-Modify graphics alghoritm to read and use directly gif files instead of make the user convert manually them
-Fix first turn problem
-Create a better GUI,a better error checking and optimize code (well it's difficult to make worse: NO GUI, a lot of redundant code,etc)
-etc.....

(8)THINGS FIXED IN THIS VERSION
-CivConverter now tries to convert also Civ and city names colors correctly
-Rules.txt and Game.txt routines has been corrected
-Fixed sprite bug which in older versions made useless graphical unit conversion

CREDITS
Let me say a big "THANK YOU!" to Cary "Astrogator" Semar and Kevin "DarthVeda" Chulski who have chosen to help me in this work and let me say also that without their help the 1.3 version of CivConverter probably would exists only in my dreams.
Special thanks goes to Jes�s Balsinde for his availability in trying to understand what causes Alba de America to crash in ToT version.
With the version 1.4 you get also a longer "thank list":
Thank to Chris "Miner" Poole for help in understanding MGE scn format and thank also to Harlan Thompson for the help in correcting some minor bugs in CivConverter.

CivConverter Copyright @ 2000 Angelo Scotto
 All Rights Reserved. 

THIS PACKAGE IS COPYRIGHT FREEWARE. NO RESPONSIBILITY IS TAKEN FOR ANY DAMAGE OR LOSSES CAUSED BY THIS PROGRAM. THIS PROGRAM AND ASSOCIATED FILES ARE DISTRIBUTED AS IS. 

THIS PROGRAM MAY NOT BE SOLD, OR DISTRIBUTED FOR ANY COMMERCIAL PURPOSES, WITHOUT PRIOR WRITTEN APPROVAL FROM THE AUTHOR. 

PROGRAM DETAILS SUBJECT TO CHANGE WITHOUT NOTICE. 

All trademarks belong to their respective owners. 