These icons have been ripped from Microsoft's Rise of Nations. Some horizontal stretching was involved, but it's barely noticeable. There are 210 in total.

Catfish
20.12.2003