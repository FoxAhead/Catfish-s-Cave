Graphics Modpack for ToT's Original Game
========================================

Installation
������������
1. Extract the zip file into your main Test of Time directory. This will create a new folder called Graphics_Mod.
2. Open this folder and double-click the file Install.bat.
3. To install the mod, type 1. The batch file will automatically backup your original files. To uninstall the mod and restore your original files, type 2. To cancel, type 3.


Game Options
������������
The units in this mod are not animated, so uncheck the Animated Units box under Graphic Options (Ctrl+P) in the Game menu. Terrain resources are animated so leave the Animated Terrain box checked.


Files
�����
Cities.bmp
Icons.bmp
People.bmp
Terrain1.bmp
Terrain2.bmp
Units.bmp
Resource.spr
Static.spr
Install.bat


Art Credits
�����������
Cities, Terrain and Units Art

I've tried to be pretty thorough in providing the correct sources for all of the graphics. Where known, signatures are provided in the graphics files:

GB = Gareth "Fairline" Birch
CS = Curt Sibling
The catfish symbol = I wonder?
Erwan = Erwan Catesson
Nemo = Captain Nemo
BB = Bernd "BeBro" Brosing
FavFly = Favoured Flight
ALEX = Alex the Magnificent
CH = Sarsstock
T = Tanelorn
PS = Pablostuka
StS = Jim Panse

MP/MB = Microprose/Hasbro
AoK = Age of Kings (Ensemble Studios)
CTP = Call To Power (Activision)
Civ3 = Civilization 3 (Firaxis)
K2 = Kohan 2 (TimeGate Studios)

People

Most of these icons were created by me from photographs. Some are derived from the game, Dark Omen by Electronic Arts. Curt Sibling has made a number of excellent modifications to this set of icons - and I've further modified some of his work. One is from Bioware's Baldur's Gate 2 (Anyone recognise Mazzy?). 

Icons

The main changes to this file are BeBro's Advances icons and Mercator's smooth tile grids.


Utilities
���������
CivSprite by Jorrit "Mercator" Vermeiren - the sprites and team colour masks (which took me bloody ages, by the way) were generated using this program.


Catfish

1/08/2004

(last updated 24/04/2006)
