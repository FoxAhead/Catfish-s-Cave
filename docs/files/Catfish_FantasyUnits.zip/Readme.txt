This is a compilation of a number of instalments of my fantasy units for Civilization 2: Test of Time. To save time, I'll just paste in modified sections from the original Readme files.

1st row: peasant with pitchfork, vampire hunter with crossbow, stakes & mandatory *cough* cigar, shield knight, foot knight, Amazon in leather bikini, elven sorceress, troll (D&D style), winged demon, elephant.
2nd row: wizard, axe-wielding sheila in traditional battle armour, crazed monk, bear, earth elemental, gnoll with scimitar, Jack o'lantern, The Reaper, yeti.
3rd row: 5 hobbits/halflings (Frodo, Sam, Merry, Pippin, generic), 2 rangers (Aragorn & Faramir), elven queen (Galadriel), ent/treant (Treebeard).
4th row: warrior monk, troll, foot knight, swordsman, halberdier, barbarian, nazgul, dwarf, sea serpent.
5th row: 5 Viking/barbarian types, sorceress, elf, ranger, female (who'd know) druid.
6th row: 2 ogres, mummy, shambling mound, mind flayer (illithid), skeleton, giant, orc with polearm, swordsman.
7th row: mummy (yeah, another one), female, dragon, owlbear, wizard, witch with broom (the original didn't have a hat - but then she stole the one from the adjacent wizard), wizard (the original miniature was of Gandalf, but this looks more like Moses parting the Red Sea), 2 dwarves.
8th row: wraith, warrior, wizard (Saruman), ranger, elf (Legolas), berserker/warrior, she-demon/succubus, rogue, warrior/ranger.
9th row: yet another sorceress type, ogre (with hydrocephalus), a couple more dudes from the Viking/barbarian series - having this time slapped on some woad, some nutter with skull, longbowman (update - he's a bit wider now), ranger, sasquatch (with hidden bikini - for William Keenan's benefit), pandaren (gotta love those Warcraft 3 neutrals).
10th row: Nazg�l, cave troll, orc, orc archer, orc, Rider of Rohan, Haradrim cavalry, Easterling cavalry, poncy-looking elf/Celeborn.
11th row: storm golem, 3 dwarves, king with sword, assassin/spy, wizard, spell-caster type, sorceress.
12th row: villager, hero, spearman, axeman, swordsman, king, knight, beholder, siege tower.
13th row: 2 giant eagles, 2 wargs/wolves, 3 wizards, swordsman/hero, dwarf.
14th row: Celtic warrior type, firbolg, pikeman, archer, elven archer, barrow-wight, ent/treant, orc, dwarf.
15th row: nazgul (Kham�l), Celtic warrior (actually done in 8-bit), vampire, ghoul, vampiress, zombie, ghost, giant bats, thief/rogue.
16th row: All Warhammer knights.
17th row: 2 knights, werewolf, marquee, various keeps, churches and cathedrals.

From the original Readme files:

Re: rows 5-8. More 24-bit fantasy units for ToT. Some of these took me a while, with some heavy retouching required.

Re: rows 10-12. A few notes: The shorter humans are generally of an older vintage � my Civ2 FW bias back then. The Rider of Rohan is a combination of a photo (rider) and a rip from AoK (horse). Similarly, the Easterling unit is a modified Erwan Mongol on an AoK horse. The Haradrim is a modified AoK camel rider on a heavy cavalry archer horse. These 3 mounted units were made before the LOTR movies came out. The beholder and siege towers are rips from Baldur�s Gate and AoM, respectively.

Re: rows 13-17. I did most of these a few years ago. They've been sitting on my HD all this time, so I decided to finally release them. The buildings are ripped from AoK.

Catfish
19.12.2003

Update (1.1.2004)
I've added another row (8th) of units. None are new. They were lying around my hard disk and I decided they were of presentable quality.

Update (23.1.2004)
Added another row of units (now mixed in rows 2 and 3). Replaced the old halfling (which sucked immensely) with the storm golem. Touched up some of the older units. Ignored some of the really old units.

Update (30.1.2004)
Added another nine units (in rows 2 and 3).

Update (21.12.2004)
Added another nine units.

Update (6.4.2005)
Added another nine units.
