Civilization 2 Test of Time
--------------------------------
CD check removal for v 1.0 (box) and 1.1 (patched)

for version 1.0 use file   tot10crk.exe
for version 1.1 use        tot11crk.exe
--------------------------------------------------------
It's a pity that Microprose decided to put a CD check into
Civilization 2, which didn't have it originally. I shouldn't 
be writing cracks at my age, but this CD check was really
getting to my nerves.

Enjoy these my first cracks!
If you want, drop me a line 

prof. Paco Ruiz

ruiz@iit.edu