This is a compilation of 24-bit terrains for use with Civilization 2: Test of Time. All of the terrains produced by me use photographs, screenshots of other games and free textures as a base. I've also added a bunch of Civilization 3 graphics to the Resources file. I've sourced the following games for these terrains: Age of Mythology, Age of Kings, Civilization 3, Starcraft and Neverwinter Nights.

I should also mention that the walls and ramparts in Terrain2-Type.bmp are graphics made by Favoured Flight, modified by Curt Sibling (for his Bitterfrost scenario) and then further modified by me (for his Test of Time version).

I'm not sure about the origin of the mountains, but I suspect Curt ripped them from another game, because originally the bases didn't quite match up. As a result, I tweaked them a bit so that they now tile better.

All of the vegetated terrains (ie, the ones with all of the little trees and bushes) are made by me. Some of these were done about 4 years ago, and although I thought they looked good at the time, I'm starting to think they're looking a little dated. Still, I like them better than most of what's on offer in the realms of Civ2 at the moment.

Catfish
19.12.2003

Recently some dedicated person asked me about the origins of some of their terrain graphics for the purposes of adding signatures. Some of them were from my collections. To avoid answering these types of questions again, I've gone through and tried (as best I could) to add signatures to all of the terrain graphics. This includes texture sources (where known), regardless of the amount of modification.

MP = Microprose
AoK = Age of Kings
AoM = Age of Mythology
K2 = Kohan 2
TT = Transport Tycoon
CTP = Call To Power
BG2 = Baldur's Gate 2
Civ3 = Civilization 3
NWN = Neverwinter Nights
RoN = Rise of Nations
SC = Starcraft
nemo = Captain Nemo
FavFly = Favoured Flight
CS = Curt Sibling
Kestrel = David "Kestrel" Hudson
mrtn = mrtn
Lin = Lineage
The catfish symbol = I wonder?

Catfish
25.02.2004
