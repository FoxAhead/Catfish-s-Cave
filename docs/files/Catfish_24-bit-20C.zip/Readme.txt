These are units designed by other authors (with the exception of the Horsa which was drawn from scratch), using the original 8-bit Civ2 palette, and "reskinned" by me in 24-bit colour for use with Test of Time. The original authors include the likes of Fairline (G.B.) and Captain Nemo, et al, as denoted by their signatures.

I've also made structural modifications to a number of them, notably the Matilda Mk II, Zero A6M (Nemo's original was a fair bit off the mark - this one still doesn't look right), Merkava I (originally a later version), Me-262, MiG-29, Panther, Jagdpanther, Su-24 and B-17.

Catfish
