24-bit Colour Terrain Pack 
==========================

This is a compilation of 24-bit terrains for use with Civilization 2: Test of Time. When creating terrain graphics I used photographs and textures (some free, some from other games) as a base. I've included texture sources (where known), regardless of the amount of modification.

I've tried to be pretty thorough in providing the correct sources for all graphics. Where known, signatures are provided in the graphics files (this was requested after I first released the pack in 2003):

MP = Microprose
AoK = Age of Kings
AoM = Age of Mythology
K2 = Kohan 2
TT = Transport Tycoon
CTP = Call To Power
BG2 = Baldur's Gate 2
Civ3 = Civilization 3
NWN = Neverwinter Nights
RoN = Rise of Nations
SC = Starcraft
nemo = Captain Nemo
FavFly = Favoured Flight
CS = Curt Sibling
Kestrel = David "Kestrel" Hudson
mrtn = mrtn
Lin = Lineage
Legion = Legion
TQ = Titan Quest
Tec = Techumseh
GB = Gareth "Fairline" Birch
The catfish symbol = I wonder?

Catfish

19/12/2003

(last updated 5/05/2009)
