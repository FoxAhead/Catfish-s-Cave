Classic Skin Set for Test of Time
=================================

Installation
������������
1. Extract the archive into your main Test of Time directory. This will create a new folder called Skins.
2. Open this folder and double-click the file Install_Classic.bat.

   Windows Vista, 7 and 8 users: 
   You may need to disable User Account Control to allow the batch file to complete the installation successfully. In my experience it has been insufficient to run the batch file installer as administrator. The alternative is to copy the files manually.

3. To install the skin, type 1. The batch file will automatically backup your original files. To uninstall the skin and restore the original files, type 2. To cancel, type 3.


Files
�����
Civwin_back.bmp
Dialog.bmp
City.bmp
Icons_original.bmp
Icons_fantasy.bmp
Icons_scifi.bmp
Install_Classic.bat


Art Credits
�����������
Microprose/Hasbro
Modifications by Catfish
Advances icons in Icons.bmp by Bernd "BeBro" Brosing
Smooth tile grids by Mercator


Changelog
���������
21/09/2014

* Added 8-frame combat animations to the Icons.bmp files for use with the Test of Time Patch Project (http://forums.civfanatics.com/showthread.php?t=517282).
* Reversed my fix of the disabled button in Dialog.bmp, as this has been addressed by the ToTPP v0.9. The ToTPP fix breaks my fix. If you see a green outline on the disabled buttons, select the 'Disabled button rendering' option in the ToTPP launcher.

05/03/2011

* Updated city.bmp.
* Slightly darkened the background tiles in civwin_back.bmp for better text readability.

03/01/2010

* Included installation instructions for Windows 7 and Vista.
* Added support for Fantasy and Sci-Fi games.

30/08/2004

* Original release.


Catfish
http://users.tpg.com.au/jpwbeest/
