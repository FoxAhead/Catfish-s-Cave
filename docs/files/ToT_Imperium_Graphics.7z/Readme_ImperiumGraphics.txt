Graphics Mod Pack for the ToT Conversion of Bernd Brosing's Imperium Romanum Scenario
=====================================================================================

This is an unofficial graphics modification for the Test of Time version of Bernd Brosing's classic Imperium Romanum scenario. In 2006, prolific Civ2 icon artist Fairline created a set of units for the converted scenario and posted his own graphics modpack in the old Scenario League forum. I'd played this scenario some years earlier using a different terrain set and this download was a mixture of those early graphics, Fairline's units, Curt Sibling's cities and people, and a more recent selection of terrain graphics. In 2013, Fairline released a second graphics modpack for the scenario. It included new units, cities and people. With his permission, this pack has been updated with these graphics.

This modpack requires the original unmodified conversion (http://forums.civfanatics.com/downloads.php?do=file&id=12464) and the Test of Time Patch Project (http://forums.civfanatics.com/showthread.php?t=517282).

Installation
============

Important: Make sure you have the updated ToTPP v0.9 or higher version of the converted scenario from the link above, otherwise you're going to encounter graphical artefacts in your game.

1. Extract the contents of the archive into the folder of the converted scenario and overwrite the original files.
2. Run the appropriate batch file (Romans, Carthaginians or Macedonians) before playing. You may need to run the batch files as an administrator.
3. You *must* have the 'Terrain overlays' option enabled in the ToTPP launcher.
4. Under Graphic Options (Ctrl+P), disable Animated Units.

Files
=====

Cities.bmp
Icons.bmp
Improvements.bmp
People.bmp
Terrain1.bmp
Terrain2.bmp
Units1.bmp
Units2.bmp
Units3.bmp
Units4.bmp

Art Credits
===========

Cities, Terrain and Units Art
�����������������������������
Where known, signatures are provided in the graphics files:

GB = Gareth "Fairline" Birch
The catfish symbol = I wonder?
BB = Bernd Brosing
Tec = Techumseh

AoK = Age of Kings (Ensemble Studios)
MP = MicroProse/Hasbro
Legion = Legion (Slitherine Software)
Civ3 = Civilization 3 (Firaxis)
AoM = Age of Mythology (Ensemble Studios)
TQ = Titan Quest (Iron Lore Entertainment)
RTW = Rome: Total War (The Creative Assembly)
SC = Starcraft (Blizzard Entertainment)

Icons
�����
Mostly Catfish, Rise of Nations (Big Huge Games), MicroProse, Gareth "Fairline" Birch and Bernd Brosing, with Mercator's smooth tile grids.

People
������
Fairline

Update:
=======

18/09/2014

* ToTPP v0.9 version. Includes 8-frame combat animation from Icons.bmp and additional Terrain2.bmp overlays.


Catfish
http://users.tpg.com.au/jpwbeest/

22/05/2009