These graphics have been converted from Warhammer: Dark Omen, Baldur's Gate, Baldur's Gate 2 and photographs. Some of the Baldur's Gate ones could probably do with a bit of work, but hey, I'm lazy.

10/08/2004


Update

I've added some 30-odd icons to the pile. Of these, all but two were created from photographs. Four of these icons are sporting headwear adapted from artwork by Curt Sibling.

Catfish

19/04/2006